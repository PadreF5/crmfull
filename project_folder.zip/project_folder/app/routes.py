# app/routes.py
from flask import render_template, redirect, url_for, flash
from app import app, db
from app.forms import RegistrationForm, LoginForm
from app.models import User
from ecdsa import SigningKey, VerifyingKey

private_key = SigningKey.generate()
public_key = private_key.get_verifying_key()

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        username = form.username.data
        signature = form.signature.data

        try:
            public_key.verify(signature, username.encode())
        except Exception as e:
            flash('Ошибка верификации подписи ЭЦП')
            return redirect(url_for('register'))

        user = User(username=username, public_key=public_key.to_pem().decode())
        db.session.add(user)
        db.session.commit()

        flash('Пользователь зарегистрирован успешно')
        return redirect(url_for('login'))

    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        signature = form.signature.data

        try:
            public_key.verify(signature, username.encode())
        except Exception as e:
            flash('Ошибка верификации подписи ЭЦП')
            return redirect(url_for('login'))

        user = User.query.filter_by(username=username).first()

        if user:
            flash('Авторизация успешна')
            return redirect(url_for('profile', username=username))

    return render_template('login.html', form=form)

@app.route('/profile/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first()
    if user:
        return render_template('profile.html', user=user)
    else:
        flash('Пользователь не найден')
        return redirect(url_for('login'))
